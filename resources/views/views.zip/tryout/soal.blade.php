@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">

                <div class="card-body">
                    <form method="POST" action="{{ route('tryout.store') }}">
                        @csrf
                        <div class="col-xl-12">
                            <div class="card">
                                <center>    
                                    Waktu
                                <div id="countdown" > 
                                    </div>
                                <div id="tempat" > 
                                    </div>
                                    
                            </center>
                            <br>
                    @foreach($datas as $data)
       
                                <div class="card-header">
                                    <h4 class="box-title">Soal {{$data->mapel}}
                                        <label class="pull-right">
                                            <a href="#">Soal ke {{$start_no+1}} /{{$total_s}}
                                            </a>
                                        </label>
                                    </h4>
                                    <br>
                                </div>
                                <br>
                         
                             <br>
                <script>
                 
                CountDownTimer('{{$times}}', 'countdown');
                function CountDownTimer(dt, id)
                {
                    var end = new Date(dt);
                    var _second = 1000;
                    var _minute = _second * 60;
                    var _hour = _minute * 60;
                    var _day = _hour * 24;
                    var timer;
                    
                    timer = setInterval(function showRemaining() {
                        var now = new Date();
                        // var tanggal= now.substring(0,2);
                        var distance = end - now;
                        if(end <= now){
                           clearInterval(timer);
                          window.location.href='/hasil-tryout';  

                        } 
                        var days = Math.floor(distance / _day);
                        var hours = Math.floor((distance % _day) / _hour);
                        var minutes = Math.floor((distance % _hour) / _minute);
                        var seconds = Math.floor((distance % _minute) / _second);
 
                        document.getElementById(id).innerHTML = hours + ':';
                        document.getElementById(id).innerHTML += minutes + ':';
                        document.getElementById(id).innerHTML += seconds ;
                        document.getElementById('tempat').innerHTML =tanggal ;
                        
                    }, 1000);
                }
            </script>
                 
            <br>
                 <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success">Petunjuk ! </span> Gunakan Petunjuk {{$data->petunjuk}} Untuk menjawab Pertanyaan Ini
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <hr>
                   
                                <div class="card-body">
                                    <div class="form-group">
                                      @if($data ->gambar_soal) 
                                       <CENTER> 
                                        <a href="{{asset('images/soal/'.$data->gambar_soal)}}" data-fancybox="gallery">

                                            <img width="300" height="300" src="{{ asset('images/soal/'.$data->gambar_soal) }}">
                                           </a>
                                        </CENTER>
                                       <br>
                                       @endif
                                       <p class="text-dark">
                                        <!-- {{$data->soal}} -->
                                        {!! nl2br(e($data->soal)) !!}

                                       <hr>
                                      <!--  <img src="https://latex.codecogs.com/gif.latex?\frac{(x^2-y^2)}{(x^2+y^2)}" border="0"/>
                                       --> 
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="jawaban" value="A"> A.
                                            @if($data->pengecekan == 'ya')
                                                <a href="{{asset('images/soal/'.$data->option_a)}}" data-fancybox="gallery">

                                                <img width="300" height="300" src="{{ asset('images/soal/'.$data->option_a) }}">
                                               </a>
                                        
                                            @else
                                             {{$data->option_a}}
                                            @endif
                                        </label>
                                        <br>
                                        <label>
                                            <input type="radio" name="jawaban" value="B"> B. 
                                            @if($data->pengecekan == 'ya')
                                                <a href="{{asset('images/soal/'.$data->option_b)}}" data-fancybox="gallery">

                                                <img width="300" height="300" src="{{ asset('images/soal/'.$data->option_b) }}">
                                               </a>
                                        
                                            @else
                                     
                                            {{$data->option_b}}
                                            @endif
                                        </label>
                                        <br>
                                        <label>
                                            <input type="radio" name="jawaban" value="C"> C. 
                                            @if($data->pengecekan == 'ya')
                                                <a href="{{asset('images/soal/'.$data->option_c)}}" data-fancybox="gallery">

                                                <img width="300" height="300" src="{{ asset('images/soal/'.$data->option_c) }}">
                                               </a>
                                        
                                            @else
                                     
                                            {{$data->option_c}}
                                            @endif

                                        </label>
                                        <br>
                                        <label>
                                            <input type="radio" name="jawaban" value="D"> D. 
                                            @if($data->pengecekan == 'ya')
                                                <a href="{{asset('images/soal/'.$data->option_d)}}" data-fancybox="gallery">

                                                <img width="300" height="300" src="{{ asset('images/soal/'.$data->option_d) }}">
                                               </a>
                                        
                                            @else
                                     
                                            {{$data->option_d}}
                                            @endif
                                        </label>
                                        <br>
                                        <label>
                                            <input type="radio" name="jawaban" value="E"> E. 
                                            @if($data->pengecekan == 'ya')
                                                <a href="{{asset('images/soal/'.$data->option_e)}}" data-fancybox="gallery">

                                                <img width="300" height="300" src="{{ asset('images/soal/'.$data->option_e) }}">
                                               </a>
                                        
                                            @else
                                     
                                            {{$data->option_e}}
                                            @endif
                                             <input type="hidden" name="kunci" value="{{$data->kunci}}">

                                            <input type="hidden" name="bidang" value="{{$akses}}">
                                                
                                            <input type="hidden" name="nilai" value="{{$nilai}}">
                                            
                                            

                                            <input type="hidden" name="off" value="{{$total_s}}">
                                         
                                        </label>  
                                        <br>
                                        
                                            
                                            
                                </div>
                      
                                <br>
                                <br>
                         <div></div>       
                        <button type="submit"  id="submit" class="btn btn-primary  pull-right">
                                Next Soal
                        </button>
                        <a href="{{url('/back-tryoutsoal')}}" class="btn btn-light" >Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endforeach
@endsection
